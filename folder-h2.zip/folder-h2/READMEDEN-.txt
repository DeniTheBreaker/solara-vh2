open the updater.exe

if is updated it well update auto


